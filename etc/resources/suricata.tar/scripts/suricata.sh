#!/bin/bash

#To be executed after the activation of the VM. Very long process

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )" 
suricata_dir=/etc/suricata


# Check for default interface.
iface=$(route | grep '^default' | grep -o '[^ ]*$')

# From repo. Contains last stable version of Suricata
add-apt-repository -y ppa:oisf/suricata-stable
apt-get -y update 
apt-get -y upgrade <<< yes 27
apt-get -y install suricata
apt-get -y upgrade <<< yes 27

# Copy Suricata configuration
cp $SCRIPT_DIR/suricata.yaml $suricata_dir
cp $SCRIPT_DIR/vars.yaml $suricata_dir

# Copy Suricata custom rules
cp $SCRIPT_DIR/signatures.rules $suricata_dir/rules

#Setup inline Suricata
iptables -I FORWARD -j NFQUEUE
#iptables -I INPUT -j NFQUEUE
#iptables -I OUTPUT -j NFQUEUE

#Disable rules when stop Suricata
#iptables -F

#Start Suricata
#TODO set screen
kill -9 $(cat /var/run/suricata.pid)
suricata -c $suricata_dir/suricata.yaml -q 0 

