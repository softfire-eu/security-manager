#!/bin/bash

touch /home/cirros/hello_world
